nombre = raw_input("cual es tu nombre?")

if nombre == "Arturo":
    print "Arturo, Que man tan Chevere"
    
elif nombre == "Jorge":
    print "Que onda Jorge"
else:
    print "Eres otro que no es Arturo o Jorge"