nombre = raw_input("Cual es tu nombre?")
edad = raw_input("Cual es tu edad?")
altura = raw_input("Cual es tu altura?")
peso = raw_input("Cual es tu peso?")
carrera = raw_input("Que estudias?")

print """Hola %s, tienes %r, %r m, altura y %r kg.
         Y estudias la carrera de %s.
         Mucho gusto en conocerte""" % (nombre,edad,altura,peso,carrera)